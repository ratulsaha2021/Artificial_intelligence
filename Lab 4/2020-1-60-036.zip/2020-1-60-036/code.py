import copy


class Node:
    def __init__(self, value, order, parent, f):
        self.value = value
        self.order = order
        self.parent = parent
        self.f = f

    def generate_child_nodes(self):
        x, y = find(self.value, 'X')

        Up_pos = [[x, y - 1], [x, y + 1], [x - 1, y], [x + 1, y]]
        children = []
        for i in Up_pos:
            child = self.move_tile(x, y, i[0], i[1])

            if child:
                child_node = Node(child, self.order + 1, self, 0)
                children.append(child_node)

        return children

    def move_tile(self, x1, y1, x2, y2):
        if 0 <= x2 < len(self.value) and 0 <= y2 < len(self.value):
            car1 = copy.deepcopy(self.value)
            temp = car1[x2][y2]
            car1[x2][y2] = car1[x1][y1]
            car1[x1][y1] = temp
            return car1
        else:
            return None

    def __str__(self):
        s = ''

        for i in self.value:
            for j in i:
                s += f'{j} '
            s += '\n'

        return s


def find(matrix, x):
    for i in range(0, len(matrix)):
        for j in range(0, len(matrix)):
            if matrix[i][j] == x:
                return i, j


def enter_matrix(n):
    matrix = []
    for i in range(0, n):
        temp = input().split(' ')
        matrix.append(temp)
    return matrix


def find2(start, goal):
    return home(start.value, goal) + start.order


def home(start, goal):
    temp = 0
    for i in range(0, len(start)):
        for j in range(0, len(start)):
            if start[i][j] != 'X':
                x, y = find(goal, start[i][j])
                temp += (abs(x - i) + abs(y - j))

    return temp


def Astar(start, goal):
    start = Node(start, 0, None, 0)
    start.f = find2(start, goal)

    q = []
    q.append(start)

    memory = {}

    last = start

    while True:
        current = q[0]

        del q[0]

        if memory.get(str(current.value)) is not None:
            continue

        last = current

        memory[str(current.value)] = True

        if home(current.value, goal) == 0:
            break

        for i in current.generate_child_nodes():
            i.f = find2(i, goal)
            q.append(i)

        q.sort(key=lambda x: x.f, reverse=False)

    path = [last]

    while last.parent is not None:
        last = last.parent
        path.append(last)

    path.reverse()

    for c, i in enumerate(path):
        print(f'step #{c + 1}')
        print(i)


if __name__ == '__main__':
    start = enter_matrix(3)
    goal = enter_matrix(3)

    Astar(start, goal)